package pesoapp;

public class Clase {
    private String fecha;
    private double peso;
    
    public Clase(String fecha, double peso){
        this.fecha = fecha; this.peso = peso;
    }

    public String getFecha() {
        return fecha;
    }

    public double getPeso() {
        return peso;
    }
    
    
}
